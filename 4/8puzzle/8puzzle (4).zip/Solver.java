import edu.princeton.cs.algs4.MinPQ;
import java.util.NoSuchElementException;
import java.lang.UnsupportedOperationException;
import java.util.Iterator;
import java.lang.IllegalArgumentException;

public class Solver {
    private MinPQ<Node> nodePq1,nodePq2;
    private boolean Solvable;
    private Node goal;
    private Node initNode ,twinNode;
    private class Node implements Comparable<Node>
    {   
        private Board board;
        private int moves;
        private Node predecessor;
        private int cost;
        public Node(Board b1,int m,Node b2)
        {
            board = b1;
            moves = m;
            predecessor = b2;
            cost = moves + board.manhattan();  //manhattan(),hamming()
        }
        public int getMoves()
        {
            return this.moves;
        }
        public Node getPredecessor()
        {
            return this.predecessor;
        } 
        public Board  getBoard()
        {
            return this.board;
        }  
        public int compareTo(Node b)
        {
            int res = 0;
            if(this.cost < b.cost ) res= -1;
            if(this.cost == b.cost) res= 0;
            if(this.cost > b.cost) res= 1;
            return res;
        }     
    }
    public Solver(Board initial)           // find a solution to the initial board (using the A* algorithm)
    {
        if(initial == null ) throw new IllegalArgumentException("IllegalArgumentException");
        this.nodePq1 =new MinPQ<Node>();
        this.nodePq2 =new MinPQ<Node>();
        this.initNode =new  Node(initial,0,null);
        this.twinNode = new Node(initial.twin(),0,null);
        nodePq1.insert(initNode);
        nodePq2.insert(twinNode);
        while(true)
        {
            //step for init
            if(nodePq1.isEmpty())
            {
                this.Solvable =false;
                break;           
            }
            Node minNow1 =nodePq1.delMin(); 
            if(minNow1.getBoard().isGoal() )
            {
                goal = minNow1;
                this.Solvable =true;
                break;
            }
            for(Board bb :minNow1.getBoard().neighbors())
            {
                Node bbNode  = new Node(bb,minNow1.getMoves()+1,minNow1);
                Node pre = minNow1.getPredecessor();
                if(pre ==null )
                    nodePq1.insert(bbNode);
                else if(null !=pre&&!pre.equals(bb))
                    nodePq1.insert(bbNode);  
            }  
            //step for twin
            if(nodePq2.isEmpty())
            {
                this.Solvable =true;    
                break;           
            }
            Node minNow2 =nodePq2.delMin(); 
            if(minNow2.getBoard().isGoal() )
            {
                this.goal = null;     
                this.Solvable =false;
                break;
            }
            for(Board b :minNow2.getBoard().neighbors())
            {
                Node bNode  = new Node(b,minNow2.getMoves()+1,minNow2);
                Node pre = minNow2.getPredecessor();
                if(pre ==null )
                    nodePq2.insert(bNode);
                if(null !=pre&&!pre.equals(b))
                    nodePq2.insert(bNode);  
            }  
        }
    }
    public boolean isSolvable()            // is the initial board solvable?
    {
        return this.Solvable;
    }
    public int moves()                     // min number of moves to solve initial board; -1 if unsolvable
    {
        if(this.isSolvable())  
        return  this.goal.getMoves();
        else return -1;
    }
    public Iterable<Board> solution()      // sequence of boards in a shortest solution; null if unsolvable
    {
        if(this.isSolvable())  
        return new Solution();
        else return null;
    }
    private class Solution implements Iterable<Board>
    {    private Board[] boards;
         private int totalNum;
         public Solution()
         {
             totalNum = moves() + 1;
             boards = new Board[totalNum];
             int cnt = totalNum - 1;
             Node now = goal;
             while(now != null)
             {
                 boards[cnt--]= now.getBoard();
                 now = now.getPredecessor();
             } 
         }
         public Iterator<Board> iterator()         // return an independent iterator over items in random order
         {
             return new BoardIterator();
         } 
         private class BoardIterator implements Iterator<Board>
         {
             private int current;
             public BoardIterator()
             {
                 current = 0;
             }
             public boolean hasNext() { 
                 return current != (totalNum);
             }
             public void remove(){throw new UnsupportedOperationException("UnsupportedOperation");}
             public Board next()
             {
                 if(!hasNext()) { throw new NoSuchElementException("NoSuchElementException"); }
                 Board item = boards[current];
                 ++current ;
                 return item;
             }
         }    
    }
    public static void main(String[] args) // solve a slider puzzle (given below)
    {
      //  int b[][]={{8,1,3},{4,0,2},{7,6,5}};
        int b[][]={{0,1,3},{4,2,5},{7,8,6}};
        int a[][]={{1,2,3},{4,5,6},{8,7,0}};
        int c[][]={{0,1,3},{4,2,5},{7,8,6}};
        Board bTest = new Board(a);
        Solver solver = new Solver(bTest.twin());
        System.out.println(solver.moves());
        System.out.println("-------------");
        if(solver.isSolvable())
        for(Board bb :solver.solution())
        {
            System.out.print(bb.toString());
            System.out.println("-------------");
        }
    }
    
}